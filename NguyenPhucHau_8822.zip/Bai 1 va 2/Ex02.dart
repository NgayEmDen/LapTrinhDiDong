void main() {
  String ten = 'Hau';

  const int tuoi = 21;

  late String moTa;
  moTa = 'Cu Bu';
  print('Mo ta cua $ten: $moTa');
  print('tuoi: $tuoi');
}
