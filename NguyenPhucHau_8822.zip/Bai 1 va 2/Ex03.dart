void main() {
  int a = 5;
  print(a++ + ++a);
  print(a-- - --a);
}
